#ifndef INPUT_H_INCLUDED
#define INPUT_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void opcionMainMenu();
void menuClientes();
void menuCuentas();
void menuMovimientos();
#endif // INPUT_H_INCLUDED
