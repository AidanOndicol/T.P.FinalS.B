#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Input.h"
#include "stDomicilio.h"
#include "stCliente.h"
#include "stCuenta.h"
#include "stMovimiento.h"
#include <time.h>
int main()
{
    srand(time(NULL));
    opcionMainMenu();

    return 0;
}
